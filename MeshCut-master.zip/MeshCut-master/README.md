# MeshCut Data Augmentation

## Introduction
This project is the code for implementing the MeshCut augmentation for image classification.